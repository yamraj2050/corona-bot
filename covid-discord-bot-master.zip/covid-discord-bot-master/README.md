# covid-discord-bot

This discord bot, fetches data from the open disease api based upon the command then returns it in the form of text, graph, chart. all resources/api's used are open source.

inspired by [covid-bot][link]

[link]:https://github.com/disease-sh/covid-bot
